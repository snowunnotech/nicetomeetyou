from django.apps import AppConfig


class NbaConfig(AppConfig):
    name = 'nba'
