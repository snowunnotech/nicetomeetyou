from django.shortcuts import render
from nba.models import NBA_NEWS

# Create your views here.
def index_view(request):
	news = NBA_NEWS.objects.all()
	return render(request, 'index.html',{
		'news' : news,
		})

def post_detail(request, pk):
	post = NBA_NEWS.objects.get(pk=pk)
	return render(request, 'post.html', {
		'post': post,
		})