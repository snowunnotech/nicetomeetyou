from django.db import models

# Create your models here.
class NBA_NEWS(models.Model):
	title = models.TextField(max_length=100)
	time = models.TextField()
	author = models.TextField(max_length=20)
	inner = models.TextField(blank=True)
	image = models.URLField(blank=True)
	url = models.URLField(blank=True)
	short = models.TextField(max_length=100)

	class Meta:
		db_table = "news"