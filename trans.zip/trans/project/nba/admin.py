from django.contrib import admin

# Register your models here.
from django.contrib import admin
from nba.models import NBA_NEWS

admin.site.register(NBA_NEWS)
