from nba.items import NbaItem
import scrapy
import time
from bs4 import BeautifulSoup

class NBASpider(scrapy.Spider):
	name = 'NBA'
	allowed_domins = ['udo.com']
	start_urls = ['https://nba.udn.com/nba/index?gr=www']
	def parse(self, response):
		domins = 'https://nba.udn.com'
		res = BeautifulSoup(response.body)
		for news in res.select('#news_body'):
			for i in range(3):
				global article_url
				article_url = domins + news.select('a')[i]['href']
				yield scrapy.Request(article_url, self.parse_detail)
	def parse_detail(self, response):
		item = NbaItem()
		res = BeautifulSoup(response.body)
		title = res.select('.story_art_title')[0].text
		time = res.select('.shareBar__info--author span')[0].text
		author = res.select('.shareBar__info--author')[0].text.split(time)[1]
		image = res.select('.photo_center a img')[0]['data-src']
		inn = res.select('#story_body_content p')
		print('-----------------START------------------')		
		print(title)
		#print(time)
		#print(author)
		#print(image)
		inner_text = ''
		for i in range(1,len(inn)):
			if inn[i].text != '':
				if inner_text != '':
					inner_text = inner_text + '\n' + inn[i].text
				else:
					inner_text = inner_text + inn[i].text
		print(inner_text)
		print('------------------END-------------------')
		item['title'] = title
		item['time'] = time
		item['author'] = author
		item['image'] = image
		item['inner_text'] = inner_text
		item['link'] = article_url
		short = inner_text.split('。')[0]
		item['short'] = short + '。...'
		yield item