from django.apps import AppConfig


class FocusConfig(AppConfig):
    name = 'focus'
