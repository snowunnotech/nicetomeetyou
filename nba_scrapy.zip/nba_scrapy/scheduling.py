import time
import os
while True:
  os.system("scrapy crawl quotes")
  time.sleep(60)